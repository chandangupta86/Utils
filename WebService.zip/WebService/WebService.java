package com.dextrosoft.WebService;

import android.app.Activity;
import android.app.ProgressDialog;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

/**
 * Created by Priya on 3/27/17.
 */

public class WebService {
    String url;
    WebServiceCallBack mWebServiceCallBack;
    Activity mActivity;
    RequestQueue queue ;
    ProgressDialog mProgressDialog;
    public static final int MY_SOCKET_TIMEOUT_MS = 90000;

    public WebService(String url, Activity activity, WebServiceCallBack webServiceCallBack) {
        this.url = url;
        this.mWebServiceCallBack = webServiceCallBack;
        this.mActivity = activity;
        this.queue = Volley.newRequestQueue(mActivity);
        this.mProgressDialog = new ProgressDialog(activity);
        mProgressDialog.setMessage("Loading");
        mProgressDialog.setCancelable(false);
    }

    public void postFormData(final Map<String, String> params, final Map<String, String> headers) {
        if(isConnectedToNet()){
            //Log.e("test","url="+url);
            //Log.e("test","params----");
            printMap(params);
            //Log.e("test","headers-----");
            printMap(headers);


             StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // response
                            Log.e("test","success-----"+response);
                            mProgressDialog.dismiss();
                            mWebServiceCallBack.successEvent(response);
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Log.e("test","error-----"+error.getMessage());
                            mProgressDialog.dismiss();
                            mWebServiceCallBack.FailureEvent(parseVolleyError(error));
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    return params;
                }
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {

                    return headers;
                }
            };
            setTimeOutData(postRequest);
            queue.add(postRequest);
            mProgressDialog.show();
        }
        else{
            mWebServiceCallBack.FailureEvent("No internet connection");
        }

    }



     public void postJsonData(final Map<String, String> params, final Map<String, String> headers){
         if(isConnectedToNet()){
             // Request a string response from the provided URL.
             /*Log.e("test","url="+url);
             Log.e("test","params----"+params);
             Log.e("test","headers-----");*/
             printMap(headers);
             StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                     new Response.Listener<String>() {
                         @Override
                         public void onResponse(String response) {
                             mProgressDialog.dismiss();
                             mWebServiceCallBack.successEvent(response);
                         }
                     }, new Response.ErrorListener() {
                 @Override
                 public void onErrorResponse(VolleyError error) {
                     // error
                     mProgressDialog.dismiss();
                     mWebServiceCallBack.successEvent(parseVolleyError(error));
                 }
             }){
                 @Override
                 public byte[] getBody() throws AuthFailureError {
                     JSONObject parameters = new JSONObject(params);
                     String data = parameters.toString();
                     return data.getBytes();
                 }
                 @Override
                 public Map<String, String> getHeaders() throws AuthFailureError {
                     return headers;
                 }
             };
             // Add the request to the RequestQueue.
             queue.add(stringRequest);
             mProgressDialog.show();
         }
         else{
             mWebServiceCallBack.FailureEvent("No internet connection");
         }

    }

    public void postJsonData(final String jsonData, final Map<String, String> headers){
        //Log.e("test","url="+url);
        //Log.e("test","params----"+jsonData);

        if(isConnectedToNet()){
            // Request a string response from the provided URL.
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Log.e("test","success-----"+response);
                            mProgressDialog.dismiss();
                            mWebServiceCallBack.successEvent(response);
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("test","error-----"+error.getMessage());
                    // error
                    mProgressDialog.dismiss();
                    mWebServiceCallBack.FailureEvent(parseVolleyError(error));
                }
            }){
                @Override
                public byte[] getBody() throws AuthFailureError {
                    return jsonData.getBytes();
                }
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    return headers;
                }
            };
            // Add the request to the RequestQueue.
            setTimeOutData(stringRequest);
            queue.add(stringRequest);
            mProgressDialog.show();
        }
        else{
            mWebServiceCallBack.FailureEvent("No internet connection");
        }

    }



    public void getStringDataFromServer() {
        if(isConnectedToNet()){
            RequestQueue queue = Volley.newRequestQueue(mActivity);
            // prepare the Request
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // Display the first 500 characters of the response string.
                            mProgressDialog.dismiss();
                            mWebServiceCallBack.successEvent(response);
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    mProgressDialog.dismiss();
                    mWebServiceCallBack.FailureEvent(parseVolleyError(error));
                }
            });

            // add it to the RequestQueue
            queue.add(stringRequest);
            mProgressDialog.show();
        }
        else {
            mWebServiceCallBack.FailureEvent("No internet connection");
        }
    }

    public void getJSONDataFromServer() {
        if(isConnectedToNet()){
            RequestQueue queue = Volley.newRequestQueue(mActivity);
            // prepare the Request
            JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            // display response
                            mProgressDialog.dismiss();
                            mWebServiceCallBack.successEvent(response.toString());

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            mProgressDialog.dismiss();
                            mWebServiceCallBack.FailureEvent(parseVolleyError(error));
                        }
                    }
            );

            // add it to the RequestQueue
            setTimeOutData(getRequest);
            queue.add(getRequest);
            mProgressDialog.show();
        }
        else {
            mWebServiceCallBack.FailureEvent("No internet connection");
        }
    }

    public boolean isConnectedToNet(){
        ConnectivityManager cm =
                (ConnectivityManager)mActivity.getSystemService(mActivity.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }

    private void printMap(Map<String, String> map){
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            //Log.e("test","key="+key+"---value="+value);
            // do stuff
        }
    }

    private String parseVolleyError(VolleyError error){
        NetworkResponse networkResponse = error.networkResponse;
        String errorMessage = "Unknown error";
        if (networkResponse == null) {
            if (error.getClass().equals(TimeoutError.class)) {
                errorMessage = "Request timeout";
            } else if (error.getClass().equals(NoConnectionError.class)) {
                errorMessage = "Failed to connect server";
            }
        } else {
            String result = new String(networkResponse.data);
            try {
                JSONObject response = new JSONObject(result);
                String status = response.getString("status");
                String message = response.getString("message");

               // Log.e("Error Status", status);
               // Log.e("Error Message", message);

                if (networkResponse.statusCode == 404) {
                    errorMessage = "Resource not found";
                } else if (networkResponse.statusCode == 401) {
                    errorMessage = message+" Please login again";
                } else if (networkResponse.statusCode == 400) {
                    errorMessage = message+ " Check your inputs";
                } else if (networkResponse.statusCode == 500) {
                    errorMessage = message+" Something is getting wrong";
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
       // Log.i("Error", errorMessage);
        error.printStackTrace();
        return errorMessage;
    }

    private void setTimeOutData(Request myRequest){
        myRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }


}
