package com.dextrosoft.WebService;


import android.app.Activity;
import android.app.ProgressDialog;

import com.dextrosoft.Utils.base.BaseResponse;
import com.dextrosoft.schoolmobileapp.R;
import com.dextrosoft.schoolmobileapp.digitaldairy.models.Attachement;
import com.dextrosoft.schoolmobileapp.digitaldairy.models.HomeWork;
import com.dextrosoft.schoolmobileapp.digitaldairy.models.request.SaveHomeWorkRequest;
import com.google.gson.Gson;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

import static com.dextrosoft.WebService.WebService.MY_SOCKET_TIMEOUT_MS;

public class RetrofitHelper {

    private RetrofitHelper.SaveEditDigitalDiaryData api;
    private RetrofitHelper.ReportCard reportCardApi;

    ProgressDialog mProgressDialog;
    Activity mActivity;
    private String baseUrl ;
    public RetrofitHelper(String baseUrl, Activity activity){
        this.baseUrl = baseUrl;
        this.mActivity = activity;
        this.mProgressDialog = new ProgressDialog(activity);
        mProgressDialog.setMessage(activity.getString(R.string.loading));
        mProgressDialog.setCancelable(false);
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient client = new OkHttpClient
                .Builder()
                .connectTimeout(MY_SOCKET_TIMEOUT_MS, TimeUnit.SECONDS)
                .writeTimeout(MY_SOCKET_TIMEOUT_MS, TimeUnit.SECONDS)
                .readTimeout(MY_SOCKET_TIMEOUT_MS, TimeUnit.SECONDS)
                .addInterceptor(interceptor)
                .build();

        Retrofit retrofit = new Retrofit
                .Builder()
                .baseUrl(this.baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(new Gson()))
                .build();
        api = retrofit.create(RetrofitHelper.SaveEditDigitalDiaryData.class);
        reportCardApi = retrofit.create(RetrofitHelper.ReportCard.class);
    }

    public void saveDigitalDiaryData(HomeWork data,Boolean isEdit,final WebServiceCallBack callBack) throws IOException {
        mProgressDialog.show();
        SaveHomeWorkRequest homeWorkData = new SaveHomeWorkRequest(data);
        ArrayList<File> files = new ArrayList<>();
        ArrayList<String> studentIds = new ArrayList<>();
        for(Attachement attachement : data.attachements){
            files.add(new File(attachement.filePath));
        }
        for(Long studentId : data.studentIds){
            studentIds.add(studentId+"");
        }
        MediaType mediaType = MediaType.parse("");//Based on the Postman logs,it's not specifying Content-Type, this is why I've made this empty content/mediaType
        MultipartBody.Part[] fileParts = new MultipartBody.Part[files.size()];
        for (int i = 0; i < files.size(); i++) {
            File file = new File(files.get(i).getPath());
            RequestBody fileBody = RequestBody.create(mediaType, file);
            //Setting the file name as an empty string here causes the same issue, which is sending the request successfully without saving the files in the backend, so don't neglect the file name parameter.
            fileParts[i] = MultipartBody.Part.createFormData(String.format(Locale.ENGLISH, "attachments[%d]", i), file.getName(), fileBody);
        }

        String schoolid = homeWorkData.schoolid+"";
        String classid = homeWorkData.classid+"";
        String sectionid = homeWorkData.sectionid+"";
        String subjectid = homeWorkData.subjectid+"";
        String teacherid = homeWorkData.teacherid+"";
        String title = homeWorkData.title;
        String homework_date = homeWorkData.homeworkDate;
        String submission_date = homeWorkData.submissionDate;
        String description = homeWorkData.description;

        Call<BaseResponse> call = isEdit ?
                api.editDigitalDiary(MultipartBody.create(mediaType, data.homeworkId+""),
                MultipartBody.create(mediaType, schoolid),
                MultipartBody.create(mediaType, classid),
                MultipartBody.create(mediaType, sectionid),
                MultipartBody.create(mediaType, subjectid),
                MultipartBody.create(mediaType, teacherid),
                MultipartBody.create(mediaType, title),
                MultipartBody.create(mediaType, homework_date),
                MultipartBody.create(mediaType, submission_date),
                MultipartBody.create(mediaType, description),
                studentIds,
                fileParts)
                :
                api.saveDigitalDiary(MultipartBody.create(mediaType, schoolid),
                        MultipartBody.create(mediaType, classid),
                        MultipartBody.create(mediaType, sectionid),
                        MultipartBody.create(mediaType, subjectid),
                        MultipartBody.create(mediaType, teacherid),
                        MultipartBody.create(mediaType, title),
                        MultipartBody.create(mediaType, homework_date),
                        MultipartBody.create(mediaType, submission_date),
                        MultipartBody.create(mediaType, description),
                        studentIds,
                        fileParts);

        call.enqueue(new Callback<BaseResponse>() {
            @Override
            public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                callBack.successEvent(new Gson().toJson(response.body()));
                mProgressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<BaseResponse> call, Throwable t) {
                callBack.FailureEvent(t.getMessage());
                mProgressDialog.dismiss();
            }
        });
    }

    public void uploadReportCard(String schoolId,int[] marksID,File reportCard,final WebServiceCallBack callBack){
        mProgressDialog.show();
        ArrayList<File> files = new ArrayList<>();
        files.add(reportCard);
        MediaType mediaType = MediaType.parse("");//Based on the Postman logs,it's not specifying Content-Type, this is why I've made this empty content/mediaType
        MultipartBody.Part[] fileParts = new MultipartBody.Part[files.size()];
        for (int i = 0; i < files.size(); i++) {
            File file = new File(files.get(i).getPath());
            RequestBody fileBody = RequestBody.create(mediaType, file);
            //Setting the file name as an empty string here causes the same issue, which is sending the request successfully without saving the files in the backend, so don't neglect the file name parameter.
            fileParts[i] = MultipartBody.Part.createFormData(String.format(Locale.ENGLISH, "report_card[%d]", i), file.getName(), fileBody);
        }
        Call<BaseResponse> call = reportCardApi.uploadReportCard(MultipartBody.create(mediaType, schoolId),
                marksID,
                fileParts);
        call.enqueue(new Callback<BaseResponse>() {
            @Override
            public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                callBack.successEvent(new Gson().toJson(response.body()));
                mProgressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<BaseResponse> call, Throwable t) {
                callBack.FailureEvent(t.getMessage());
                mProgressDialog.dismiss();
            }
        });
    }

    public static interface SaveEditDigitalDiaryData {
        //https://stackoverflow.com/questions/37223092/is-it-possible-to-send-a-string-through-multipart-using-retrofit/40675674
        @Multipart
        @POST("save_EditHomework.php")
        Call<BaseResponse> saveDigitalDiary(@Part("schoolid") RequestBody schoolid,
                                            @Part("classid") RequestBody classid,
                                            @Part("sectionid") RequestBody sectionid,
                                            @Part("subjectid") RequestBody subjectid,
                                            @Part("teacherid") RequestBody teacherid,
                                            @Part("title") RequestBody title,
                                            @Part("homework_date") RequestBody homework_date,
                                            @Part("submission_date") RequestBody submission_date,
                                            @Part("description") RequestBody description,
                                            @Part("studentid[]") ArrayList<String> studentid,
                                            @Part MultipartBody.Part[] files);
        Call<BaseResponse> editDigitalDiary(@Part("id") RequestBody homeWorkId,
                                            @Part("schoolid") RequestBody schoolid,
                                            @Part("classid") RequestBody classid,
                                            @Part("sectionid") RequestBody sectionid,
                                            @Part("subjectid") RequestBody subjectid,
                                            @Part("teacherid") RequestBody teacherid,
                                            @Part("title") RequestBody title,
                                            @Part("homework_date") RequestBody homework_date,
                                            @Part("submission_date") RequestBody submission_date,
                                            @Part("description") RequestBody description,
                                            @Part("studentid[]") ArrayList<String> studentid,
                                            @Part MultipartBody.Part[] files);
    }

    public static interface ReportCard {

        @Multipart
        @POST("uploadReportCard.php")
        Call<BaseResponse> uploadReportCard(@Part("schoolid") RequestBody schoolid,
                                            @Part("marks_id[]") int[] studentid,
                                            @Part MultipartBody.Part[] files);

    }

}
