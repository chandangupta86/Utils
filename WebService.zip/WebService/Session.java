package com.dextrosoft.WebService;

import com.dextrosoft.schoolmobileapp.login.model.StudentLoginResponse;
import com.dextrosoft.schoolmobileapp.login.model.TeacherLoginResponse;

public class Session {
    public static String securityToken = "xyz"; //@TODO need to be dymnaic from login response
    public static int schoolId = 2;             //@TODO need to be dymnaic from login response
    public static int userType ;
    public static StudentLoginResponse mStudentLoginResponse;
    public static TeacherLoginResponse mTeacherLoginResponse;
    public static String localeCode = "en" ;
    public static void clearSession(){
        securityToken = null;
        schoolId = -1;
        userType = -1;
        mStudentLoginResponse = null;
        mTeacherLoginResponse = null;
    }
}
