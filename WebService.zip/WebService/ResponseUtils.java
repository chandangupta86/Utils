package com.dextrosoft.WebService;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.dextrosoft.Utils.Utils;
import com.dextrosoft.Utils.base.BaseResponse;
import com.dextrosoft.schoolmobileapp.Attandance.model.AttendanceSummaryListbyTeacherIdResponse;
import com.dextrosoft.schoolmobileapp.Attandance.model.GetAttendaceListResponse;
import com.dextrosoft.schoolmobileapp.Attandance.model.response.MonthlyAttendanceSummaryResponse;
import com.dextrosoft.schoolmobileapp.aboutusAdmission.model.AboutUsResponse;
import com.dextrosoft.schoolmobileapp.aboutusAdmission.model.response.FeeListResponse;
import com.dextrosoft.schoolmobileapp.aboutusAdmission.model.response.TransportFeeResponse;
import com.dextrosoft.schoolmobileapp.aboutusAdmission.model.response.TransportRoutesResponse;
import com.dextrosoft.schoolmobileapp.academics.model.AcademicsResponse;
import com.dextrosoft.schoolmobileapp.digitaldairy.models.response.ClassListResponse;
import com.dextrosoft.schoolmobileapp.digitaldairy.models.response.HomeWorkListResponse;
import com.dextrosoft.schoolmobileapp.digitaldairy.models.response.SectionListResponse;
import com.dextrosoft.schoolmobileapp.digitaldairy.models.response.StudentListResponse;
import com.dextrosoft.schoolmobileapp.digitaldairy.models.response.SubjectListResponse;
import com.dextrosoft.schoolmobileapp.timetable.model.response.ExamTimeTableResponse;
import com.dextrosoft.schoolmobileapp.facilities.model.FacilityResponse;
import com.dextrosoft.schoolmobileapp.gallery.model.EventGalleryResponse;
import com.dextrosoft.schoolmobileapp.holiday.model.SchoolHolidayResponse;
import com.dextrosoft.schoolmobileapp.login.model.StudentLoginResponse;
import com.dextrosoft.schoolmobileapp.login.model.TeacherLoginResponse;
import com.dextrosoft.schoolmobileapp.notice.model.NoticeResponse;
import com.dextrosoft.schoolmobileapp.reportCard.model.ExamListResponse;
import com.dextrosoft.schoolmobileapp.reportCard.model.response.GetStudentMarksResponse;
import com.dextrosoft.schoolmobileapp.reportCard.model.response.GetStudentMarksSummaryResponse;
import com.dextrosoft.schoolmobileapp.reportCard.model.response.InsertMarksResponse;
import com.dextrosoft.schoolmobileapp.schoolDetails.model.SchoolDetailsResponse;
import com.dextrosoft.schoolmobileapp.syllabus.model.response.SyllabusResponse;
import com.dextrosoft.schoolmobileapp.timetable.model.response.ClassTimetableResponse;
import com.dextrosoft.schoolmobileapp.tutorialLinks.model.GetTutorialListResponse;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class ResponseUtils {
    public static final String BASE_URL        = "https://appeaseonlinestore.com/appEaseEdu/webservices/";
    //public static final String BASE_URL            = "http://10.0.2.2/appEaseEdu/webservices/";

   // public static final String IMAGE_BASE_URL       = "https://appeaseonlinestore.com/appEaseEdu/images/";
   // public static final String BASE_URL_LOCAL = "http://10.0.2.2:5000/";
   // public static final String HOLIDAY_IMAGES_FOLDER = "holidaylist/";

    public static final int EVENT_GALLERY   = 1;
    public static final int NOTICE          = 2;
    public static final int HOLIDAY_LIST    = 3;
    public static final int FACILITY        = 4;
    public static final int STUDENT_LOGIN   = 5;
    public static final int TEACHER_LOGIN   = 6;
    public static final int ABOUT_US        = 7;
    public static final int PARENT_LOGIN    = 8;
    public static final int ACADEMICS       = 9;
    public static final int ADMISSION       = 10;
    public static final int ACTIVITY        = 11;
    public static final int STUDENT_DASHBOARD = 12;
    //Tutorial Links
    public static final int ADD_TUTORIAL     = 13;
    public static final int GET_TUTORIAL_BY_TEACHER_ID     = 14;
    public static final int DELETE_TUTORIAL     = 15;
    public static final int TUTORIAL_LIST_BY_CLASS_SECTION_ID     = 16;
    //class section subject
    public static final int CLASS_LIST       = 17;
    public static final int SECTION_LIST     = 18;
    public static final int SUBJECT_LIST     = 19;
    public static final int EXAM_LIST        = 20;

    //attedanceStatus
    //Attendance
    public static final int SAVE_ATTENDANCE     = 21;
    public static final int UPDATE_ATTENDANCE   = 22;
    public static final int DELETE_ATTENDANCE   = 23;
    public static final int GET_ATTENDANCE_STATUS = 24;
    public static final int GET_ATTENDANCE_SUMMARY_LIST_BY_TEACHER_ID = 25;
    public static final int GET_MONTHLY_ATTENDANCE_SUMMARY_LIST_BY_STUDENT_ID = 26;
    public static final int DELETE_ATTENDANCE_BY_CLASS_SECTION_DATE = 27;

    //Digital Diary
    public static final int STUDENT_LIST   = 28;
    public static final int SAVE_EDIT_HOMEWORK   = 29;
    public static final int HOMEWORK_LIST_BY_TEACHER_ID   = 30;
    public static final int HOMEWORK_LIST_BY_STUDENT_ID   = 31;
    public static final int SCHOOL_DETAILS   = 32;

    //REPORT CARD
    public static final int GET_STUDENT_MARKS   = 33;
    public static final int INSERT_STUDENT_MARKS   = 34;
    public static final int UPLOAD_REPORT_CARD   = 35;
    public static final int EDIT_STUDENT_MARKS   = 36;
    public static final int GET_STUDENT_MARK_SUMMARY   = 37;

    //Transport
    public static final int GET_TRANSPORT_ROUTE   = 38;
    public static final int GET_TRANSPORT_FEE   = 39;

    //Fee
    public static final int GET_FEE_DETAILS   = 40;

    //Time table
    public static final int GET_CLASS_TIME_TABLE   = 41;
    //download syllabus
    public static final int DOWNLOAD_SYLLABUS   = 42;
    public static final int GET_EXAM_TIME_TABLE   = 43;










    private static final String STUDENT_LOGIN_SERVICE    = "login.php";
    private static final String TEACHER_LOGIN_SERVICE    = "teacherLogin.php";
    private static final String ABOUT_US_SERVICE         = "getAboutUs.php";
    private static final String ACADEMICS_SERVICE        = "getAllTeacherDetails.php";
    private static final String HOLIDAY_LIST_SERVICE     = "getHolidayCalendar.php";
    private static final String FACILITY_SERVICE         = "getFacility.php";
    private static final String NOTICE_SERVICE           = "getNotice.php";
    private static final String EVENT_GALLERY_SERVICE    = "getEventsGallery.php";
    //Tutorial Links
    private static final String ADD_TUTORIAL_SERVICE     = "add_EditTutorial.php";
    private static final String GET_TUTORIAL_BY_TEACHER_ID_SERVICE     = "getTutorialListByTeacherId.php";
    private static final String DELETE_TUTORIAL_SERVICE     = "deleteTutorialLink.php";
    private static final String TUTORIAL_LIST_BY_CLASS_SECTION_ID_SERVICE     = "getTutorialListByClassIdSectionId.php";

    //class , section , subject , exam list
    private static final String CLASS_LIST_SERVICE       = "getClassDetails.php";
    private static final String SECTION_LIST_SERVICE     = "getSectionDetails.php";
    private static final String SUBJECT_LIST_SERVICE     = "getSubjectDetails.php";
    private static final String EXAM_LIST_SERVICE        = "getAllExamList.php";

    //Attendance
    private static final String SAVE_ATTENDANCE_SERVICE            = "saveAttendanceStatus.php";
    private static final String UPDATE_ATTENDANCE_SERVICE          = "updateAttendanceStatus.php";
    private static final String DELETE_ATTENDANCE_SERVICE          = "deleteAttendance.php";
    private static final String GET_ATTENDANCE_STATUS_SERVICE      = "getAttendanceList.php";
    private static final String DELETE_ATTENDANCE_BY_CLASS_SECTION_DATE_SERVICE      = "deleteAttendanceByClassSectionDate.php";
    private static final String GET_ATTENDANCE_SUMMARY_LIST_BY_TEACHER_ID_SERVICE      = "getAttendanceSummaryListbyTeacherId.php";
    private static final String GET_MONTHLY_ATTENDANCE_SUMMARY_LIST_BY_STUDENT_ID_SERVICE      = "getMonthlyAttendanceSummaryListbyStudentId.php";

    //Report card
    private static final String GET_STUDENT_MARKS_SERVICE      = "getStudentMarks.php";
    private static final String INSERT_STUDENT_MARKS_SERVICE      = "insertStudentMarks.php";
    private static final String UPLOAD_REPORT_CARD_SERVICE      = "uploadReportCard.php";
    private static final String EDIT_STUDENT_MARKS_SERVICE      = "editStudentMarks.php";
    private static final String GET_STUDENT_MARK_SUMMARY_SERVICE      = "getStudentMarksSummary.php";
    private static final String SCHOOL_DETAILS_SERVICE      = "getSchoolDetails.php";

    //Digital Diary
    private static final String STUDENT_LIST_SERVICE   = "getStudentList.php";
    private static final String SAVE_EDIT_HOMEWORK_SERVICE   = "save_EditHomework.php";
    private static final String HOMEWORK_LIST_BY_TEACHER_ID_SERVICE   = "getHomeWorkListByTeacherId.php";
    private static final String HOMEWORK_LIST_BY_STUDENT_ID_SERVICE   = "getHomeWorkListByStudentId.php";

    //Transport
    private static final String GET_TRANSPORT_ROUTE_SERVICE   = "getTransportRoute.php";
    private static final String GET_TRANSPORT_FEE_SERVICE   = "getTransportFee.php";

    //Fee
    private static final String GET_FEE_DETAILS_SERVICE   = "getFeeDetails.php";
    //Time table
    private static final String GET_CLASS_TIME_TABLE_SERVICE   = "getClassTimeTable.php";
    private static final String GET_EXAM_TIME_TABLE_SERVICE   = "getExamTimeTable.php";

    //syllabus
    private static final String DOWNLOAD_SYLLABUS_SERVICE   = "downLoadSyllabus.php";




    public static BaseResponse getMockResponse(Context context, int resType, String resString) {
        BaseResponse eventRes = null;
        String localeCode = Utils.getLocale(context);
        String fileName = null ;
        Type type = null;
        try{
            switch (resType){
                case EVENT_GALLERY:
                    fileName = "response/eventgallery.json";
                    type = new TypeToken<EventGalleryResponse>(){}.getType();
                    break;
                case NOTICE:
                    fileName = "response/notice.json";
                    type = new TypeToken<NoticeResponse>(){}.getType();
                    break;
                case HOLIDAY_LIST:
                    fileName = "response/holiday.json";
                    type = new TypeToken<SchoolHolidayResponse>(){}.getType();
                    break;
                case FACILITY:
                    fileName = "response/facility.json";
                    type = new TypeToken<FacilityResponse>(){}.getType();
                    break;
                case STUDENT_LOGIN:
                    fileName = "response/studentLogin.json";
                    type = new TypeToken<StudentLoginResponse>(){}.getType();
                    break;
                case TEACHER_LOGIN:
                    fileName = "response/teacherLogin.json";
                    type = new TypeToken<TeacherLoginResponse>(){}.getType();
                    break;
                case ABOUT_US:
                    fileName = "response/aboutUsResonse.json";
                    type = new TypeToken<AboutUsResponse>(){}.getType();
                    break;
                case ACADEMICS:
                    fileName = "response/Academics.json";
                    type = new TypeToken<AcademicsResponse>(){}.getType();
                    break;
                case ADMISSION:
                    fileName = "response/admissionResonse.json";
                    type = new TypeToken<AboutUsResponse>(){}.getType();
                    break;
                case ACTIVITY:
                    fileName = "response/activitiesResponse.json";
                    type = new TypeToken<AboutUsResponse>(){}.getType();
                    break;
                case STUDENT_DASHBOARD:
                    fileName = "response/studentDashboardResponse_"+localeCode+".json";
                    //fileName = "response/studentDashboardResponse.json";
                    type = new TypeToken<AboutUsResponse>(){}.getType();
                    break;
                case GET_TUTORIAL_BY_TEACHER_ID:
                case TUTORIAL_LIST_BY_CLASS_SECTION_ID:
                    fileName = "response/GetTutorialListResponse.JSON";
                    type = new TypeToken<GetTutorialListResponse>(){}.getType();
                    break;
                case CLASS_LIST:
                    fileName = "response/classListResponse.json";
                    type = new TypeToken<ClassListResponse>(){}.getType();
                    break;
                case SUBJECT_LIST:
                    fileName = "response/subjectListResponse.json";
                    type = new TypeToken<SubjectListResponse>(){}.getType();
                    break;
                case SECTION_LIST:
                    fileName = "response/sectionListResponse.json";
                    type = new TypeToken<SectionListResponse>(){}.getType();
                    break;
                case STUDENT_LIST:
                    fileName = "response/studentList.json";
                    type = new TypeToken<StudentListResponse>(){}.getType();
                    break;
                case HOMEWORK_LIST_BY_TEACHER_ID:
                case HOMEWORK_LIST_BY_STUDENT_ID:
                    fileName = "response/homeWorkList.json";
                    type = new TypeToken<HomeWorkListResponse>(){}.getType();
                    break;
                case GET_ATTENDANCE_STATUS:
                    fileName = "response/getAttendaceListResponse.json";
                    type = new TypeToken<GetAttendaceListResponse>(){}.getType();
                    break;
                case EXAM_LIST:
                    fileName = "response/examListResponse.json";
                    type = new TypeToken<ExamListResponse>(){}.getType();
                    break;
                case SCHOOL_DETAILS:
                    //fileName = "response/examListResponse.json";
                    type = new TypeToken<SchoolDetailsResponse>(){}.getType();
                    break;
                case GET_ATTENDANCE_SUMMARY_LIST_BY_TEACHER_ID:
                    //fileName = "response/examListResponse.json";
                    type = new TypeToken<AttendanceSummaryListbyTeacherIdResponse>(){}.getType();
                    break;
                case GET_MONTHLY_ATTENDANCE_SUMMARY_LIST_BY_STUDENT_ID:
                    fileName = "response/MonthlyAttendanceSummaryResponse.json";
                    type = new TypeToken<MonthlyAttendanceSummaryResponse>(){}.getType();
                    break;
                case GET_STUDENT_MARKS:
                    fileName = "response/MonthlyAttendanceSummaryResponse.json";
                    type = new TypeToken<GetStudentMarksResponse>(){}.getType();
                    break;
                case INSERT_STUDENT_MARKS:
                case EDIT_STUDENT_MARKS:
                    fileName = "response/MonthlyAttendanceSummaryResponse.json";
                    type = new TypeToken<InsertMarksResponse>(){}.getType();
                    break;
                case GET_STUDENT_MARK_SUMMARY:
                    fileName = "response/MonthlyAttendanceSummaryResponse.json";
                    type = new TypeToken<GetStudentMarksSummaryResponse>(){}.getType();
                    break;
                case GET_TRANSPORT_ROUTE:
                    fileName = "response/MonthlyAttendanceSummaryResponse.json";
                    type = new TypeToken<TransportRoutesResponse>(){}.getType();
                    break;
                case GET_FEE_DETAILS:
                    type = new TypeToken<FeeListResponse>(){}.getType();
                    break;
                case GET_TRANSPORT_FEE:
                    type = new TypeToken<TransportFeeResponse>(){}.getType();
                    break;
                case GET_CLASS_TIME_TABLE:
                    type = new TypeToken<ClassTimetableResponse>(){}.getType();
                    break;
                case DOWNLOAD_SYLLABUS:
                    type = new TypeToken<SyllabusResponse>(){}.getType();
                    break;
                case GET_EXAM_TIME_TABLE:
                    type = new TypeToken<ExamTimeTableResponse>(){}.getType();
                    break;



                case ADD_TUTORIAL:
                case DELETE_TUTORIAL:
                case SAVE_ATTENDANCE:
                case UPDATE_ATTENDANCE:
                case DELETE_ATTENDANCE:
                case SAVE_EDIT_HOMEWORK:
                case DELETE_ATTENDANCE_BY_CLASS_SECTION_DATE:
                case UPLOAD_REPORT_CARD:
                    fileName = "response/baseResponse.json";
                    type = new TypeToken<BaseResponse>(){}.getType();
                    break;
            }
            String eventsJson = (resString!=null) ? resString : Utils.readFromAssets(context,fileName);
            eventRes = new GsonBuilder().create().fromJson(eventsJson, type);
        }
        catch (Exception e){
            Log.e("test","---"+e.getMessage());
        }
        finally {
            return  eventRes;
        }
    }

    public static void getActualResponse(int reqType, Activity activity,String request, WebServiceCallBack webServiceCallBack){
        String url = null;
        switch (reqType) {
            case STUDENT_LOGIN:
                url = BASE_URL + STUDENT_LOGIN_SERVICE;
                break;
            case TEACHER_LOGIN:
                url = BASE_URL + TEACHER_LOGIN_SERVICE;
                break;
            case ABOUT_US:
                url = BASE_URL + ABOUT_US_SERVICE;
                break;
            case ACADEMICS:
                url = BASE_URL + ACADEMICS_SERVICE;
                break;
            case HOLIDAY_LIST:
                url = BASE_URL + HOLIDAY_LIST_SERVICE;
                break;
            case FACILITY:
                url = BASE_URL + FACILITY_SERVICE;
                break;
            case NOTICE:
                url = BASE_URL + NOTICE_SERVICE;
                break;
            case ADD_TUTORIAL:
                url = BASE_URL + ADD_TUTORIAL_SERVICE;
                break;
            case DELETE_TUTORIAL:
                url = BASE_URL + DELETE_TUTORIAL_SERVICE;
                break;
            case GET_TUTORIAL_BY_TEACHER_ID:
                url = BASE_URL + GET_TUTORIAL_BY_TEACHER_ID_SERVICE;
                break;
            case CLASS_LIST:
                url = BASE_URL + CLASS_LIST_SERVICE;
                break;
            case SECTION_LIST:
                url = BASE_URL + SECTION_LIST_SERVICE;
                break;
            case SUBJECT_LIST:
                url = BASE_URL + SUBJECT_LIST_SERVICE;
                break;
            case EVENT_GALLERY:
                url = BASE_URL + EVENT_GALLERY_SERVICE;
                break;
            case SAVE_ATTENDANCE:
                url = BASE_URL + SAVE_ATTENDANCE_SERVICE;
                break;
            case UPDATE_ATTENDANCE:
                url = BASE_URL + UPDATE_ATTENDANCE_SERVICE;
                break;
            case DELETE_ATTENDANCE:
                url = BASE_URL + DELETE_ATTENDANCE_SERVICE;
                break;
            case STUDENT_LIST:
                url = BASE_URL + STUDENT_LIST_SERVICE;
                break;
            case TUTORIAL_LIST_BY_CLASS_SECTION_ID:
                url = BASE_URL + TUTORIAL_LIST_BY_CLASS_SECTION_ID_SERVICE;
                break;
            case SAVE_EDIT_HOMEWORK:
                url = BASE_URL + SAVE_EDIT_HOMEWORK_SERVICE;
                break;
            case HOMEWORK_LIST_BY_TEACHER_ID:
                url = BASE_URL + HOMEWORK_LIST_BY_TEACHER_ID_SERVICE;
                break;
            case HOMEWORK_LIST_BY_STUDENT_ID:
                url = BASE_URL + HOMEWORK_LIST_BY_STUDENT_ID_SERVICE;
                break;
            case GET_ATTENDANCE_STATUS:
                url = BASE_URL + GET_ATTENDANCE_STATUS_SERVICE;
                break;
            case EXAM_LIST:
                url = BASE_URL + EXAM_LIST_SERVICE;
                break;
            case SCHOOL_DETAILS:
                url = BASE_URL + SCHOOL_DETAILS_SERVICE;
                break;
            case GET_ATTENDANCE_SUMMARY_LIST_BY_TEACHER_ID:
                url = BASE_URL + GET_ATTENDANCE_SUMMARY_LIST_BY_TEACHER_ID_SERVICE;
                break;
            case GET_MONTHLY_ATTENDANCE_SUMMARY_LIST_BY_STUDENT_ID:
                url = BASE_URL + GET_MONTHLY_ATTENDANCE_SUMMARY_LIST_BY_STUDENT_ID_SERVICE;
                break;
            case DELETE_ATTENDANCE_BY_CLASS_SECTION_DATE:
                url = BASE_URL + DELETE_ATTENDANCE_BY_CLASS_SECTION_DATE_SERVICE;
                break;
            case GET_STUDENT_MARKS:
                url = BASE_URL + GET_STUDENT_MARKS_SERVICE;
                break;
            case INSERT_STUDENT_MARKS:
                url = BASE_URL + INSERT_STUDENT_MARKS_SERVICE;
                break;
            case UPLOAD_REPORT_CARD:
                url = BASE_URL + UPLOAD_REPORT_CARD_SERVICE;
                break;
            case EDIT_STUDENT_MARKS:
                url = BASE_URL + EDIT_STUDENT_MARKS_SERVICE;
                break;
            case GET_STUDENT_MARK_SUMMARY:
                url = BASE_URL + GET_STUDENT_MARK_SUMMARY_SERVICE;
                break;
            case GET_TRANSPORT_ROUTE:
                url = BASE_URL + GET_TRANSPORT_ROUTE_SERVICE;
                break;
            case GET_FEE_DETAILS:
                url = BASE_URL + GET_FEE_DETAILS_SERVICE;
                break;
            case GET_TRANSPORT_FEE:
                url = BASE_URL + GET_TRANSPORT_FEE_SERVICE;
                break;
            case GET_CLASS_TIME_TABLE:
                url = BASE_URL + GET_CLASS_TIME_TABLE_SERVICE;
                break;
            case DOWNLOAD_SYLLABUS:
                url = BASE_URL + DOWNLOAD_SYLLABUS_SERVICE;
                break;
            case GET_EXAM_TIME_TABLE:
                url = BASE_URL + GET_EXAM_TIME_TABLE_SERVICE;
                break;
        }

        WebService webService = new WebService(url,activity,webServiceCallBack);
        webService.postJsonData(request,getHeaders());
    }

    public static Map<String, String> getHeaders(){
        Map<String, String> headers = new HashMap<>();
        return headers;
    }
}
