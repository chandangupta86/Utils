package com.dextrosoft.WebService;

import com.dextrosoft.Utils.DateUtils;
import com.dextrosoft.schoolmobileapp.Attandance.model.SaveAttendanceRequest;
import com.dextrosoft.schoolmobileapp.Attandance.model.StudentAttendanceModel;
import com.dextrosoft.schoolmobileapp.Attandance.model.UpdateAttendanceRequest;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class RequestUtils {

    public static final String STUDENT_LOGIN_REQUEST           = "{\"user_type\":%s,\"registration_no\":\"%s\",\"password\":\"%s\"}";
    public static final String TEACHER_LOGIN_REQUEST           = "{\"user_type\":%s,\"email\":\"%s\",\"password\":\"%s\"}";
    public static final String SCHOOL_ID_SECURITY_KEY_REQUEST  = "{\"school_id\":%d,\"security_key\":\"%s\"}";
    public static final String ABOUT_US_SERVICE_REQUEST        = "{\"school_id\":%d,\"parent_id\":\"%d\"}";
    public static final String ADD_TUTORIAL_SERVICE_REQUEST    = "{\"schoolid\":%d,\"classid\":%d,\"sectionid\":%d,\"subjectid\":%d,\"teacherid\":%d,\"title\":\"%s\",\"url\":\"%s\",\"duration\":\"%s\"}";
    public static final String EDIT_TUTORIAL_SERVICE_REQUEST    = "{\"schoolid\":%d,\"classid\":%d,\"sectionid\":%d,\"subjectid\":%d,\"teacherid\":%d,\"title\":\"%s\",\"url\":\"%s\",\"duration\":\"%s\",\"id\":\"%s\"}";
    public static final String GET_TUTORIAL_BY_TEACHER_ID_SERVICE_REQUEST    = "{\"school_id\":%d,\"teacherId\":%d}";
    public static final String DELETE_TUTORIAL_SERVICE_REQUEST = "{\"tutorialId\":%s}";
    public static final String SUBJECT_LIST_SERVICE_REQUEST    = "{\"school_id\":%d,\"class_id\":%d,\"section_id\":%d,\"security_key\":\"%s\"}";
    public static final String SECTION_LIST_REQUEST  = "{\"school_id\":%d,\"class_id\":%d,\"security_key\":\"%s\"}";
    public static final String SUBJECT_LIST_REQUEST  = "{\"school_id\":%d,\"class_id\":%d,\"section_id\":%d,\"security_key\":\"%s\"}";
    public static final String DELETE_ATTENDANCE_REQUEST = "{\"security_key\":\"%s\",\"attendance_id\":%d}";
    public static final String STUDENT_LIST_REQUEST = "{\"schoolId\":%d,\"classId\":%d,\"sectionId\":%d,\"security_key\":\"%s\"}";
    public static final String HOMEWORK_LIST_REQUEST = "{\"school_id\":%d,\"userid\":%d,\"security_key\":\"%s\"}";
    public static final String GET_ATTENDANCE_STATUS_REQUEST = "{\"school_id\":%d,\"class_id\":%d,\"section_id\":%d,\"security_key\":\"%s\",\"date\":\"%s\"}";
    public static final String GET_ATTENDANCE_SUMMARY_LIST_BY_TEACHER_ID_REQUEST = "{\"security_key\":\"%s\",\"schoolid\":%d,\"teacherid\":%d}";
    public static final String DELETE_ATTENDANCE_BY_CLASS_SECTION_DATE = "{\"security_key\":\"%s\",\"school_id\":%d,\"class_id\":%d,\"section_id\":%d,\"date\":\"%s\"}";
    public static final String GET_MONTHLY_ATTENDANCE_SUMMARY_LIST_BY_STUDENT_ID_REQUEST = "{\"schoolid\":%d,\"security_key\":\"%s\",\"studentid\":%d}";
    public static final String GET_STUDENT_MARKS_SERVICE = "{\"school_id\":%d,\"security_key\":\"%s\",\"studentDetails\":{\"classId\":%d,\"sectionId\":%d,\"examId\":%d,\"studentId\":%d}}";
    public static final String GET_STUDENT_MARKS_SUMMARY = "{\"school_id\":%d,\"student_id\":%d,\"security_key\":\"%s\"}";
    public static final String GET_CLASS_TIME_TABLE = "{\"school_id\":%d,\"class_id\":%d,\"section_id\":%d,\"security_key\":\"%s\"}";
    public static final String GET_EXAM_TIME_TABLE_REQUEST = "{\"school_id\":%d,\"class_id\":%d,\"section_id\":%d,\"security_key\":\"%s\"}";
    public static final String DOWNLOAD_SYLLABUS_REQUEST = "{\"school_id\":%d,\"class_id\":%s,\"security_key\":\"%s\"}";


    public static final int USER_TYPE_TEACHER                   =   1 ;
    public static final int USER_TYPE_STUDENT                   =   2;
    public static final int USER_TYPE_PARENT                    =   3 ;


    public static String  getSaveAttendanceRequest(List<StudentAttendanceModel> data){
        ArrayList<SaveAttendanceRequest> list = new ArrayList<SaveAttendanceRequest>();
        for (StudentAttendanceModel item : data){
            String datee = DateUtils.getStringDateFromTimestamp(item.attendanceDateInt,DateUtils.yyyy_mm_dd, Session.localeCode);
            list.add(new SaveAttendanceRequest(datee,(int)item.classId,item.sectionId+"",Integer.parseInt(Session.mTeacherLoginResponse.academics.teacherId),item.studentBasicInfo.studentId,item.attedanceStatus));
        }
        Gson gson = new Gson();
        return  gson.toJson(list);
    }

    public static String  getUpdateAttendanceRequest(List<StudentAttendanceModel> data){
        ArrayList<SaveAttendanceRequest> list = new ArrayList<SaveAttendanceRequest>();
        for (StudentAttendanceModel item : data){
            String datee = DateUtils.getStringDateFromTimestamp(item.attendanceDateInt,DateUtils.yyyy_mm_dd, Session.localeCode);
            list.add(new UpdateAttendanceRequest((int)item.attendanceId,datee,(int)item.classId,item.sectionId+"",Integer.parseInt(Session.mTeacherLoginResponse.academics.teacherId),item.studentBasicInfo.studentId,item.attedanceStatus));
        }
        Gson gson = new Gson();
        return  gson.toJson(list);
    }
}
