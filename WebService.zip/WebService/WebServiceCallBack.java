package com.dextrosoft.WebService;

/**
 * Created by Priya on 3/27/17.
 */

public interface WebServiceCallBack {
    public void successEvent(String data);
    public void FailureEvent(String data);
}
